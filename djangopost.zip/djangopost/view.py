import random
from django.shortcuts import *
from django.http import *
from django.views.decorators.csrf import *
from django.core.files.storage import *
from pymysql import *

conn=connect("127.0.0.1",'root',"","practice")

def loadaddcontact(request):
    return render(request,"addcontact.html")

@csrf_exempt
def insertcontact(request):
    global conn
    myfile= request.FILES["friendphoto"]
    fs = FileSystemStorage()
    rn = random.randint(1, 10000)
    pic="photos/" + str(rn) + myfile.name
    print(pic)
    fs.save(pic, myfile)
    s="insert into friends values(NULL,'"+request.POST['email']+"','"+request.POST['fullname']+"','"+request.POST['mobile']+"','"+str(pic)+"')"
    cr=conn.cursor()
    cr.execute(s)
    conn.commit()
    return render(request,"insertcontact.html")

def showcontact(request):
    global conn
    s1="select * from friends"
    cr=conn.cursor()
    cr.execute(s1)
    result= cr.fetchall()
    print(result)
    x=[]
    for row in result:
        d={}
        d["fullname"]=row[2]
        d["mobile"]=row[3]
        d["photo"]=row[4]
        x.append(d)
    return render(request,"showcontact.html",{"ar":x})

def open(request):
    return render(request,"filechooser.html")

def save(request):
    fs = FileSystemStorage()

    myfile1=request.FILES["pic1"]
    rn =random.randint(1,10000)
    fs.save("myphotos/"+str(rn)+myfile1.name,myfile1)

    myfile2=request.FILES["pic2"]
    rn =random.randint(1,10000)
    fs.save("secondfolder/"+str(rn)+myfile2.name,myfile2)

    myfile3=request.FILES["pic3"]
    rn =random.randint(1,10000)
    fs.save("thirdfolder/"+str(rn)+myfile3.name,myfile3)
    return HttpResponse("File Uploaded")

def opensignup(request):
    return render(request,"one.html")

def insert(request):
    s="insert into user values ('"+request.POST["email"]+"','"+request.POST["password"]+"','"+request.POST["dob"]+"','"+request.POST["mobile"]+"','"+request.POST["otp"]+"')"
    global conn
    query="select * from user"
    cr=conn.cursor()
    cr.execute(query)
    result=cr.fetchall()
    flag=False
    for row in result:
        if str(row[0])==str(request.POST["email"]):
            flag=True
            break
    if flag==True:
        d={"errorcode":1}
    else:
        cr.execute(s)
        conn.commit()
        d={"errorcode":0}
    return render(request,"displayerror.html",{"ar":d})


def contactus(request):
    return render(request,"contactus.html")

def aboutus(request):
    return render(request,"aboutus.html")

def userlogin(request):
    return render(request,"userlogin.html")

def userhome(request):
    return render(request,"userhome.html")

def checklogin(request):
    global conn
    query = "select * from user"
    cr=conn.cursor()
    cr.execute(query)
    result = cr.fetchall()
    flag = False
    for row in result:
        if str(row[0])==str(request.POST["email"]) and str(row[1])==str(request.POST["password"]):
            flag=True
            break
    if flag==False:
        d={"errorcode":2}
        return render(request,"displayerror.html",{"ar":d})
    else:
        return HttpResponseRedirect("userhome")

def passwordreset(request):
    return render(request,"passwordreset.html")

def reset(request):
    global conn
    query="select * from user where email='"+request.POST["email"]+"'"
    cr=conn.cursor()
    cr.execute(query)
    if cr.rowcount>0:
        row=cr.fetchone()
        mobile=row[3]
        otp=random.randint(1000,9999)
        query2="update user set otp ="+str(otp)+" where email ='"+str(request.POST["email"])+"'"
        cr.execute(query2)
        conn.commit()
    else:
        d={"errorcode":3}
        return render(request,"displayerror.html",{"ar":d})
    d={"email":request.POST["email"]}
    return render(request,"reset.html",{"ar":d})

def updatepassword(request):
    otp=int(request.POST["o"]+request.POST["t"]+request.POST["p"]+request.POST["1"])
    global conn
    query ="select * from user where email='"+request.POST["email"]+"' and otp ="+str(otp)
    cr=conn.cursor()
    cr.execute(query)
    if cr.rowcount>0:
        query1="update user set password ='"+request.POST["newpassword"]+"',otp=0 where email='"+request.POST["email"]+"'"
        cr.execute(query1)
        conn.commit()
        return HttpResponseRedirect("userlogin")
    else:
        d={"errorcode":4}
        return render(request,"displayerror.html",{"ar":d})