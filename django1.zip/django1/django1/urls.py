"""django1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from music.views import *
from view import test1
from view import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path("cha",test1),
    path("man",test2),
    path("fack",show),
    # path("inputmarks",inputmarks),
    path("showresult",showresult),
    path("inputnumbers",inputnumbers),
    path("shownum",shownum),
    path("demotable",demotable),
    path("search",search),
    path("showcars",showcars),
    path("enterstudent",enterstudent),
    path("studenttable",studenttable),
    path("showstudenttable",showstudenttable),
    path("updateformsubmit",updateformsubmit),
    path("updateform",updateform),
    path("deleteform",deleteform),
    path('dial',dial),
    path('openrandomhtml',openrandomhtml),
    path('generaterandom',generaterandom)
   ]
