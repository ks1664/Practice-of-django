from django.shortcuts import render
from django.shortcuts import *
from django.http import *
# Create your views here.

def loadhome(request):
    return render(request,"homepage.html")