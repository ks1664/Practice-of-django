import random
from pymysql import *
from django.shortcuts import *
from django.http import *

con = connect("127.0.0.1", "root", "", "practice")


def dial(request):
    return render(request,"dial.html")

def deleteform(request):
    global con
    cr = con.cursor()
    id = request.GET["id"]
    sql4="DELETE FROM studenttable WHERE (id='"+str(id)+"');"
    cr.execute(sql4)
    con.commit()
    return redirect(showstudenttable)


def updateform(request):
    global con
    cr = con.cursor()
    id = request.GET["id"]
    name = request.GET["name"]
    fname=request.GET["fname"]
    bgroup=request.GET["bgroup"]
    city=request.GET["city"]
    mobile=request.GET["mobile"]
    sql3="UPDATE studenttable SET name='"+str(name)+"',fathername='"+str(fname)+"',bloodgroup='"+str(bgroup)+"',city='"+str(city)+"',mobile='"+str(mobile)+"' WHERE (id='"+str(id)+"');"
    cr.execute(sql3)
    con.commit()
    return redirect(showstudenttable)

    # return render(request,".showstudenttable")

def updateformsubmit(request):
    global con
    cr = con.cursor()
    id = request.GET["id"]
    sql2 = "select * from studenttable where id='" + str(id) + "'"
    cr.execute(sql2)
    res = cr.fetchall()
    print(res)
    empty = []
    for row in res:
        dis = {}
        dis["id"] = row[0]
        dis["name"] = row[1]
        dis["fname"] = row[2]
        dis["bgroup"] = row[3]
        dis["city"] = row[4]
        dis["mobile"] = row[5]
        empty.append(dis)
    print(empty)
    return render(request, "updateprofile.html", {"ans": empty})


def enterstudent(request):
    return render(request, "dataentry.html")


def studenttable(request):
    global con
    cr = con.cursor()
    name = request.GET["name"]
    fname = request.GET["fname"]
    bg = request.GET["bg"]
    city = request.GET["city"]
    mobile = request.GET["mobile"]
    sql = "INSERT INTO studenttable(`name`, `fathername`, `bloodgroup`, `city`, `mobile`) VALUES('" + str(
        name) + "','" + str(fname) + "','" + str(bg) + "','" + str(city) + "','" + str(mobile) + "');"
    print(sql)
    cr.execute(sql)
    con.commit()
    print(sql)
    return redirect(showstudenttable)


def showstudenttable(request):
    global con
    cr = con.cursor()
    sql = "select * from studenttable"
    cr.execute(sql)
    res = cr.fetchall()
    empty = []
    for row in res:
        dis = {}
        dis["id"] = row[0]
        dis["name"] = row[1]
        dis["fathername"] = row[2]
        dis["bloodgroup"] = row[3]
        dis["city"] = row[4]
        dis["mobile"] = row[5]
        empty.append(dis)
    # print(empty)
    return render(request, "showstudent.html", {"ans": empty})


def showcars(request):
    return render(request, "showcars.html")


def demotable(request):
    global con
    cr = con.cursor()
    sql = "select * from demotable"
    cr.execute(sql)
    res = cr.fetchall()
    empty = []
    for row in res:
        dis = {}
        dis["name"] = row[0]
        dis["rollno"] = row[1]
        dis["course"] = row[2]
        dis["marks"] = row[3]
        empty.append(dis)
    # print(empty)
    return render(request, "showtable.html", {"ans": empty})


# def demotable(request):
#     x=[
#         {"rollno": 1, "name": "Ajay", "course": "BCA"},
#         {"rollno": 2, "name": "Django", "course": "MCA"},
#         {"rollno": 3, "name": "Machine", "course": "BCA"},
#         {"rollno": 4, "name": "React", "course": "MCA"},
#         {"rollno": 5, "name": "C", "course": "BCA"},
#         {"rollno": 6, "name": "C++", "course": "MCA"},
#         {"rollno": 7, "name": "Python", "course": "BCA"},
#         {"rollno": 8, "name": "Java", "course": "MCA"},
#         {"rollno": 9, "name": "Ajax", "course": "BCA"},
#         {"rollno": 10, "name": "Akay", "course": "MCA"}
#     ]
#     return render(request,"showtable.html",{"ans":x})

def search(request):
    # x = [
    #     {"rollno": 1, "name": "Ajay", "course": "BCA"},
    #     {"rollno": 2, "name": "Django", "course": "MCA"},
    #     {"rollno": 3, "name": "Machine", "course": "BCA"},
    #     {"rollno": 4, "name": "React", "course": "MCA"},
    #     {"rollno": 5, "name": "C", "course": "BCA"},
    #     {"rollno": 6, "name": "C++", "course": "MCA"},
    #     {"rollno": 7, "name": "Python", "course": "BCA"},
    #     {"rollno": 8, "name": "Java", "course": "MCA"},
    #     {"rollno": 9, "name": "Ajax", "course": "BCA"},
    #     {"rollno": 10, "name": "Akay", "course": "MCA"}
    # ]
    global con
    cr = con.cursor()
    sql = "select * from demotable"
    cr.execute(sql)
    res = cr.fetchall()
    empty = []
    for row in res:
        dis = {}
        dis["name"] = row[0]
        dis["rollno"] = row[1]
        dis["course"] = row[2]
        dis["marks"] = row[3]
        empty.append(dis)
    rno = request.GET["textbox1"]
    y = []
    for r in empty:
        if str(r["rollno"]) == rno:
            y.append(r)
    return render(request, "showtable.html", {"ans": y})

    # def inputmarks(request):
    # return render(request,"inputmarks.html")


def showresult(request):
    total = int(request.GET["textbox1"]) + int(request.GET["textbox2"]) + int(request.GET["textbox3"]) + int(
        request.GET["textbox4"]) + int(request.GET["textbox5"])
    per = (total / 500) * 100
    d = {"percent": per}
    return render(request, "showmarks.html", {"ans": d})


def inputnumbers(request):
    return render(request, "enternumber.html")


def shownum(request):
    s = request.GET["textbox1"]
    ar = s.split(",")
    x = []
    for p in ar:
        x.append(int(p))
    t = sum(x)
    a = sum(x) / len(x)
    m = max(x)
    n = min(x)
    d = {"total": t, "average": a, "max": m, "min": n}
    return render(request, "shownumber.html", {"ans": d})


def show5(request):
    return render(request, "input.html")


def show4(request):
    s = request.GET["textbox1"]
    t = request.GET["tb2"]
    u = request.GET["tb3"]
    v = request.GET["tb4"]
    d = {"name": s, "age": t, "mobile": u, "mail": v}
    return render(request, "output.html", {"ans": d})


def test1(request):
    p = "<h1>Hello world i am learning python</h1>"
    s = "<table>"
    for i in range(1, 11):
        s = s + "<tr>"
        s = s + "<td>" + str(i) + "</td>"
        s = s + "<td>Apple</td>"
        s = s + "<td>60</td>"
        s = s + "</tr>"
    s = s + "</table>"
    return HttpResponse(s + p)


def test2(request):
    t = random.random()
    ans = "<h1>" + str(t) + "</h1>"
    return HttpResponse(ans)


def show(request):
    num = 9
    if num < 0:
        print("Sorry, factorial does not exist for negative numbers")
    elif num == 0:
        print("The factorial of 0 is 1")
    else:
        for i in range(1, num + 1):
            factorial = factorial * i
        print("The factorial of", num, "is", factorial)

def openrandomhtml(request):
    return render(request,"randomhtml.html")

def generaterandom(request):
    return HttpResponse("ok")



